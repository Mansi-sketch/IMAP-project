const ESPDetector = require('./ESPDetector');
const ReceivingChainAnalyzer = require('./ReceivingChainAnalyzer');
const MockEmailGenerator = require('./MockEmailGenerator');
const { EmailAnalysis } = require('../models/EmailAnalysis');
const { getDB } = require('../config/database');

class EmailAnalysisService {
    static async analyzeEmail(emailData) {
        const startTime = Date.now();
        
        // Convert headers to string for ESP detection
        const headersText = JSON.stringify(emailData.raw_headers);
        
        // Detect ESP
        const { esp: espType, confidence } = ESPDetector.detectESP(headersText);
        
        // Extract receiving chain
        const receivingChain = ReceivingChainAnalyzer.extractReceivingChain(emailData.raw_headers);
        
        // Create analysis object
        const analysis = new EmailAnalysis({
            sender_email: emailData.sender_email,
            raw_headers: emailData.raw_headers,
            receiving_chain: receivingChain,
            esp_type: espType,
            esp_confidence: confidence,
            analysis_duration_ms: Date.now() - startTime
        });
        
        // Store in database
        const db = getDB();
        await db.collection('email_analyses').insertOne(analysis);
        
        return analysis;
    }

    static async getRecentAnalyses(limit = 10) {
        const db = getDB();
        const analyses = await db.collection('email_analyses')
            .find({})
            .sort({ processed_at: -1 })
            .limit(limit)
            .toArray();
        
        return analyses;
    }

    static async clearAllAnalyses() {
        const db = getDB();
        const result = await db.collection('email_analyses').deleteMany({});
        return result.deletedCount;
    }

    static async getTotalAnalysesCount() {
        const db = getDB();
        return await db.collection('email_analyses').countDocuments({});
    }

    static async createDemoAnalysis(espType = null) {
        // Generate sample email headers
        const sampleHeaders = MockEmailGenerator.generateSampleEmail(espType);
        
        // Create analysis request
        const emailData = {
            sender_email: sampleHeaders.from,
            raw_headers: sampleHeaders
        };
        
        return await this.analyzeEmail(emailData);
    }
}

module.exports = EmailAnalysisService;