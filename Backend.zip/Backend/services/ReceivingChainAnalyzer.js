class ReceivingChainAnalyzer {
    static extractReceivingChain(headers) {
        let receivedHeaders = [];

        // Handle different header formats
        if (headers.received) {
            receivedHeaders = Array.isArray(headers.received) ? headers.received : [headers.received];
        } else if (headers.Received) {
            receivedHeaders = Array.isArray(headers.Received) ? headers.Received : [headers.Received];
        }

        const chain = [];

        receivedHeaders.forEach((received, index) => {
            if (typeof received === 'string') {
                const serverInfo = this.parseReceivedHeader(received);
                serverInfo.hop_number = index + 1;
                chain.push(serverInfo);
            }
        });

        // If no received headers, create mock chain for demo
        if (chain.length === 0) {
            return this.createMockReceivingChain();
        }

        return chain;
    }

    static parseReceivedHeader(received) {
        // Extract server information using regex
        const fromMatch = received.match(/from\s+([^\s\(]+)/i);
        const byMatch = received.match(/by\s+([^\s\(]+)/i);
        const dateMatch = received.match(/;\s*(.+)$/);

        return {
            from_server: fromMatch ? fromMatch[1] : 'unknown',
            by_server: byMatch ? byMatch[1] : 'unknown',
            timestamp: dateMatch ? dateMatch[1].trim() : 'unknown',
            raw_header: received
        };
    }

    static createMockReceivingChain() {
        return [
            {
                hop_number: 1,
                from_server: 'mail.example.com',
                by_server: 'mx1.gmail.com',
                timestamp: 'Mon, 1 Jan 2024 10:00:00 +0000',
                raw_header: 'Received: from mail.example.com by mx1.gmail.com'
            },
            {
                hop_number: 2,
                from_server: 'smtp.sender.com',
                by_server: 'mail.example.com',
                timestamp: 'Mon, 1 Jan 2024 09:59:58 +0000',
                raw_header: 'Received: from smtp.sender.com by mail.example.com'
            }
        ];
    }
}

module.exports = ReceivingChainAnalyzer;