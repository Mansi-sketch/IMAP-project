const errorHandler = (error, req, res, next) => {
    console.error('Unhandled error:', error);
    
    // MongoDB errors
    if (error.name === 'MongoError') {
        return res.status(500).json({
            error: 'Database error',
            message: 'An error occurred while processing your request'
        });
    }
    
    // Validation errors
    if (error.name === 'ValidationError') {
        return res.status(400).json({
            error: 'Validation error',
            message: error.message
        });
    }
    
    // Default error
    res.status(500).json({
        error: 'Internal server error',
        message: 'An unexpected error occurred'
    });
};

module.exports = errorHandler;