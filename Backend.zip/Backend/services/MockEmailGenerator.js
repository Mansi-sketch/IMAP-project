class MockEmailGenerator {
    static SAMPLE_HEADERS = {
        gmail: {
            received: [
                'from mail-oi1-f44.google.com (mail-oi1-f44.google.com. [209.85.167.44]) by mx.example.com with ESMTPS id abc123 for <test@example.com>; Mon, 1 Jan 2024 10:00:00 +0000',
                'by mail.gmail.com with SMTP id xyz789; Mon, 1 Jan 2024 09:59:58 +0000'
            ],
            from: 'sender@gmail.com',
            subject: 'EMAIL_ANALYSIS_TEST_' + Math.floor(Math.random() * 9000 + 1000)
        },
        outlook: {
            received: [
                'from NAM02-DM3-obe.outbound.protection.outlook.com by mx.example.com; Mon, 1 Jan 2024 10:00:00 +0000',
                'by DM6PR0402MB3245.outlook.com; Mon, 1 Jan 2024 09:59:58 +0000'
            ],
            from: 'sender@outlook.com',
            subject: 'EMAIL_ANALYSIS_TEST_' + Math.floor(Math.random() * 9000 + 1000)
        },
        sendgrid: {
            received: [
                'from o1.email.sendgrid.net by mx.example.com; Mon, 1 Jan 2024 10:00:00 +0000',
                'by smtp.sendgrid.net; Mon, 1 Jan 2024 09:59:58 +0000'
            ],
            from: 'noreply@company.com',
            subject: 'EMAIL_ANALYSIS_TEST_' + Math.floor(Math.random() * 9000 + 1000)
        },
        yahoo: {
            received: [
                'from mta1.mail.yahoo.com by mx.example.com; Mon, 1 Jan 2024 10:00:00 +0000',
                'by smtp.mail.yahoo.com; Mon, 1 Jan 2024 09:59:58 +0000'
            ],
            from: 'user@yahoo.com',
            subject: 'EMAIL_ANALYSIS_TEST_' + Math.floor(Math.random() * 9000 + 1000)
        },
        'amazon-ses': {
            received: [
                'from a1-1.smtp-out.amazonses.com by mx.example.com; Mon, 1 Jan 2024 10:00:00 +0000',
                'by email-smtp.us-east-1.amazonaws.com; Mon, 1 Jan 2024 09:59:58 +0000'
            ],
            from: 'notifications@company.com',
            subject: 'EMAIL_ANALYSIS_TEST_' + Math.floor(Math.random() * 9000 + 1000)
        },
        mailchimp: {
            received: [
                'from mail1.mailchimp.com by mx.example.com; Mon, 1 Jan 2024 10:00:00 +0000',
                'by mcsv.net with SMTP; Mon, 1 Jan 2024 09:59:58 +0000'
            ],
            from: 'newsletter@company.com',
            subject: 'EMAIL_ANALYSIS_TEST_' + Math.floor(Math.random() * 9000 + 1000)
        },
        mailgun: {
            received: [
                'from smtp.mailgun.org by mx.example.com; Mon, 1 Jan 2024 10:00:00 +0000',
                'by mxa.mailgun.org; Mon, 1 Jan 2024 09:59:58 +0000'
            ],
            from: 'support@company.com',
            subject: 'EMAIL_ANALYSIS_TEST_' + Math.floor(Math.random() * 9000 + 1000)
        },
        postmark: {
            received: [
                'from smtp.postmarkapp.com by mx.example.com; Mon, 1 Jan 2024 10:00:00 +0000',
                'by pmta01.postmarkapp.com; Mon, 1 Jan 2024 09:59:58 +0000'
            ],
            from: 'alerts@company.com',
            subject: 'EMAIL_ANALYSIS_TEST_' + Math.floor(Math.random() * 9000 + 1000)
        }
    };

    static generateSampleEmail(espType = null) {
        if (!espType) {
            const types = Object.keys(this.SAMPLE_HEADERS);
            espType = types[Math.floor(Math.random() * types.length)];
        }
        
        // Handle case where frontend sends 'amazon ses' but we have 'amazon-ses'
        if (espType.toLowerCase() === 'amazon ses') {
            espType = 'amazon-ses';
        }
        
        return this.SAMPLE_HEADERS[espType] || this.SAMPLE_HEADERS.gmail;
    }

    static getAvailableESPTypes() {
        return Object.keys(this.SAMPLE_HEADERS);
    }
}

module.exports = MockEmailGenerator;