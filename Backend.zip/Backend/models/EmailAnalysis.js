const { v4: uuidv4 } = require('uuid');

class EmailAnalysis {
    constructor({
        sender_email,
        raw_headers,
        receiving_chain,
        esp_type,
        esp_confidence,
        analysis_duration_ms
    }) {
        this.id = uuidv4();
        this.email_address = "test-email-analysis@demo.com";
        this.subject_line = raw_headers.subject || 'EMAIL_ANALYSIS_TEST';
        this.sender_email = sender_email;
        this.receiving_chain = receiving_chain;
        this.esp_type = esp_type;
        this.esp_confidence = esp_confidence;
        this.raw_headers = raw_headers;
        this.processed_at = new Date();
        this.analysis_duration_ms = analysis_duration_ms;
    }
}

class SystemStatus {
    constructor(totalEmailsProcessed) {
        this.email_address = "test-email-analysis@demo.com";
        this.subject_line = "EMAIL_ANALYSIS_TEST";
        this.imap_status = "Demo Mode - Ready";
        this.last_check = new Date().toISOString();
        this.total_emails_processed = totalEmailsProcessed;
    }
}

// Validation functions
const validateEmailAnalysisInput = (data) => {
    const errors = [];
    
    if (!data.sender_email) {
        errors.push('sender_email is required');
    } else if (typeof data.sender_email !== 'string') {
        errors.push('sender_email must be a string');
    }
    
    if (!data.raw_headers) {
        errors.push('raw_headers is required');
    } else if (typeof data.raw_headers !== 'object') {
        errors.push('raw_headers must be an object');
    }
    
    return errors;
};

module.exports = {
    EmailAnalysis,
    SystemStatus,
    validateEmailAnalysisInput
};