class ESPDetector {
    static ESP_PATTERNS = {
        'Gmail': [
            /smtp\.gmail\.com/i,
            /mail-.*\.google\.com/i,
            /by mail\.gmail\.com/i,
            /received.*gmail\.com/i
        ],
        'Outlook': [
            /smtp.*\.outlook\.com/i,
            /.*\.outlook\.com/i,
            /by.*outlook\.com/i,
            /protection\.outlook\.com/i
        ],
        'Yahoo': [
            /smtp.*\.mail\.yahoo\.com/i,
            /mta.*\.mail\.yahoo\.com/i,
            /by.*yahoo\.com/i
        ],
        'Amazon SES': [
            /amazonaws\.com/i,
            /email-smtp.*\.amazonaws\.com/i,
            /ses.*\.amazonaws\.com/i
        ],
        'SendGrid': [
            /sendgrid\.net/i,
            /smtp\.sendgrid\.net/i,
            /by.*sendgrid/i
        ],
        'Mailchimp': [
            /mailchimp\.com/i,
            /mcsv\.net/i,
            /by.*mailchimp/i
        ],
        'Mailgun': [
            /mailgun\.org/i,
            /smtp.*\.mailgun\.org/i
        ],
        'Postmark': [
            /postmarkapp\.com/i,
            /smtp\.postmarkapp\.com/i
        ]
    };

    static detectESP(headersText) {
        const headersLower = headersText.toLowerCase();
        const espScores = {};

        for (const [esp, patterns] of Object.entries(this.ESP_PATTERNS)) {
            let score = 0;
            for (const pattern of patterns) {
                const matches = (headersLower.match(pattern) || []).length;
                score += matches;
            }
            
            if (score > 0) {
                espScores[esp] = score;
            }
        }

        if (Object.keys(espScores).length === 0) {
            return { esp: "Unknown", confidence: 0.0 };
        }

        // Get ESP with highest score
        const bestESP = Object.keys(espScores).reduce((a, b) => 
            espScores[a] > espScores[b] ? a : b
        );
        const maxScore = espScores[bestESP];

        // Calculate confidence (normalize to 0-1)
        const confidence = Math.min(maxScore / 3.0, 1.0);

        return { esp: bestESP, confidence };
    }
}

module.exports = ESPDetector;