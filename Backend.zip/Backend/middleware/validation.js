const { validateEmailAnalysisInput } = require('../models/EmailAnalysis');

const validateEmailAnalysis = (req, res, next) => {
    const errors = validateEmailAnalysisInput(req.body);
    
    if (errors.length > 0) {
        return res.status(400).json({
            error: 'Validation failed',
            details: errors
        });
    }
    
    next();
};

const validateLimit = (req, res, next) => {
    let { limit } = req.query;
    
    if (limit) {
        limit = parseInt(limit);
        if (isNaN(limit) || limit < 1 || limit > 100) {
            return res.status(400).json({
                error: 'limit must be a number between 1 and 100'
            });
        }
        req.query.limit = limit;
    }
    
    next();
};

module.exports = {
    validateEmailAnalysis,
    validateLimit
};